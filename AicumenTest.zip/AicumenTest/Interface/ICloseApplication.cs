﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AicumenTest.Interface
{
    public interface ICloseApplication
    {
        void closeApplication();
    }
}
